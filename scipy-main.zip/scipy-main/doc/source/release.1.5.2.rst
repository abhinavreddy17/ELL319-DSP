.. include:: ../release/1.5.2-notes.rst
