.. include:: ../release/0.7.1-notes.rst
