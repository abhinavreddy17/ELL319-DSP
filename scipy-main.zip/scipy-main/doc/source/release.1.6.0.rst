.. include:: ../release/1.6.0-notes.rst
