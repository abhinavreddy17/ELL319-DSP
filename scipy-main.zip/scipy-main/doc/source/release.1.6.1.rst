.. include:: ../release/1.6.1-notes.rst
