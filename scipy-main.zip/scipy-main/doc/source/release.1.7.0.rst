.. include:: ../release/1.7.0-notes.rst
