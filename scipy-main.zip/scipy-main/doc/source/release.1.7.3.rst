.. include:: ../release/1.7.3-notes.rst
