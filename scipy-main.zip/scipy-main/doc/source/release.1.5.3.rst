.. include:: ../release/1.5.3-notes.rst
