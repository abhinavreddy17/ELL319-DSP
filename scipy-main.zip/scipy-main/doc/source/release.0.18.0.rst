.. include:: ../release/0.18.0-notes.rst
