.. include:: ../release/1.2.3-notes.rst
