.. include:: ../release/1.7.2-notes.rst
