.. include:: ../release/0.19.0-notes.rst
