.. include:: ../release/1.5.0-notes.rst
