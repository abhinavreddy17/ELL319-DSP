.. include:: ../release/1.6.2-notes.rst
