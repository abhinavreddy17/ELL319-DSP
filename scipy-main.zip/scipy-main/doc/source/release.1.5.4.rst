.. include:: ../release/1.5.4-notes.rst
