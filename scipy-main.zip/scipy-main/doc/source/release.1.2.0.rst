.. include:: ../release/1.2.0-notes.rst
