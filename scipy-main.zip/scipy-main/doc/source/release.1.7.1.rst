.. include:: ../release/1.7.1-notes.rst
