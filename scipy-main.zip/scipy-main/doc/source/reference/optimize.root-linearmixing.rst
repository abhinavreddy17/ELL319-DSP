.. _optimize.root-linearmixing:

root(method='linearmixing')
------------------------------------------

.. scipy-optimize:function:: scipy.optimize.root
   :impl: scipy.optimize._root._root_linearmixing_doc
   :method: linearmixing
