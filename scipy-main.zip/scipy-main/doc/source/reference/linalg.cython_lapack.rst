.. automodule:: scipy.linalg.cython_lapack
   :no-members:
   :no-inherited-members:
   :no-special-members:
