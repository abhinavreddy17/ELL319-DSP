.. automodule:: scipy.constants
   :no-members:
   :no-inherited-members:
   :no-special-members:
