.. automodule:: scipy.sparse.csgraph
   :no-members:
   :no-inherited-members:
   :no-special-members:
