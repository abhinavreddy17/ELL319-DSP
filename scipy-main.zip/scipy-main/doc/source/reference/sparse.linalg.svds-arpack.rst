.. _sparse.linalg.svds-arpack:

svds(solver='arpack')
----------------------------------------

.. scipy-optimize:function:: scipy.sparse.linalg.svds
   :impl: scipy.sparse.linalg._eigen._svds_doc._svds_arpack_doc
   :method: arpack
