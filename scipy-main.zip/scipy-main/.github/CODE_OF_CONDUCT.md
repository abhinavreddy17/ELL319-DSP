SciPy Code of Conduct
======

You can read our Code of Conduct by following [this link](../doc/source/dev/conduct/code_of_conduct.rst). 


Alternatively, you can find it under `scipy/doc/source/dev/conduct/code_of_conduct.rst`. 

